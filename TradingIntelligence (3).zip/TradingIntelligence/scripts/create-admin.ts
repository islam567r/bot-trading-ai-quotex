import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { db } from "../server/db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function createAdmin() {
  // Delete existing admin user
  await db.delete(users).where(eq(users.username, 'admin'));

  const hashedPassword = await hashPassword("admin123");

  await db.insert(users).values({
    username: "admin",
    password: hashedPassword,
    quotexEmail: "admin@quotex.com",
    quotexAccountId: "ADMIN",
    isActive: true,
    isAdmin: true
  });

  console.log("Admin user created successfully");
  process.exit(0);
}

createAdmin().catch(console.error);