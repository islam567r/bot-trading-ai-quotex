
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { Search, Users, Pencil, Trash } from "lucide-react";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { format, addMonths } from "date-fns";
import { ar } from "date-fns/locale";

export default function AdminPanel() {
  const { user, logoutMutation } = useAuth();
  const [search, setSearch] = useState("");
  const [, setLocation] = useLocation();
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState({
    username: "",
    quotexEmail: "",
    quotexAccountId: "",
    password: "",
  });

  if (!user?.isAdmin) {
    setLocation("/");
    return null;
  }

  const { data: users = [] } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const toggleUserMutation = useMutation({
    mutationFn: async ({ id, isActive, subscriptionEndsAt }: { id: number; isActive: boolean; subscriptionEndsAt?: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${id}`, { isActive, subscriptionEndsAt });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setSelectedUser(null);
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/admin/users/${selectedUser.id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setEditMode(false);
      setSelectedUser(null);
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/admin/users/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setSelectedUser(null);
    },
  });

  const filteredUsers = users.filter(
    (u: any) =>
      u.username.toLowerCase().includes(search.toLowerCase()) ||
      u.quotexEmail.toLowerCase().includes(search.toLowerCase()) ||
      u.quotexAccountId.toLowerCase().includes(search.toLowerCase())
  );

  const stats = {
    total: users.length,
    active: users.filter((u: any) => u.isActive).length,
    inactive: users.filter((u: any) => !u.isActive).length,
  };

  const handleActivateUser = (user: any) => {
    const subscriptionEndsAt = addMonths(new Date(), 1).toISOString();
    toggleUserMutation.mutate({ id: user.id, isActive: true, subscriptionEndsAt });
  };

  const handleEdit = (user: any) => {
    setSelectedUser(user);
    setEditData({
      username: user.username,
      quotexEmail: user.quotexEmail,
      quotexAccountId: user.quotexAccountId,
      password: "",
    });
    setEditMode(true);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">لوحة تحكم المسؤول</h1>
          <Button variant="outline" onClick={() => logoutMutation.mutate()}>
            تسجيل الخروج
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">إجمالي المستخدمين</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المستخدمين النشطين</CardTitle>
              <Users className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.active}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المستخدمين غير النشطين</CardTitle>
              <Users className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.inactive}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>إدارة المستخدمين</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2 mb-4">
              <Search className="w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="البحث باسم المستخدم، البريد الإلكتروني أو رقم الحساب..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="flex-1"
              />
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>اسم المستخدم</TableHead>
                    <TableHead>بريد Quotex</TableHead>
                    <TableHead>رقم الحساب</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>تاريخ انتهاء الاشتراك</TableHead>
                    <TableHead>الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user: any) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.username}</TableCell>
                      <TableCell>{user.quotexEmail}</TableCell>
                      <TableCell>{user.quotexAccountId}</TableCell>
                      <TableCell>
                        <Badge variant={user.isActive ? "default" : "secondary"}>
                          {user.isActive ? "مفعل" : "غير مفعل"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.subscriptionEndsAt ? (
                          format(new Date(user.subscriptionEndsAt), "d MMMM yyyy", { locale: ar })
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant={user.isActive ? "destructive" : "default"}
                            onClick={() => setSelectedUser(user)}
                          >
                            {user.isActive ? "إلغاء التفعيل" : "تفعيل"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(user)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              if (confirm("هل أنت متأكد من حذف هذا المستخدم؟")) {
                                deleteUserMutation.mutate(user.id);
                              }
                            }}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* حوار تفعيل/إلغاء تفعيل المستخدم */}
        <Dialog open={!!selectedUser && !editMode} onOpenChange={() => setSelectedUser(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {selectedUser?.isActive ? "تأكيد إلغاء تفعيل الحساب" : "تأكيد تفعيل الحساب"}
              </DialogTitle>
              <DialogDescription>
                {selectedUser?.isActive
                  ? "هل أنت متأكد من رغبتك في إلغاء تفعيل هذا الحساب؟"
                  : "سيتم تفعيل الحساب لمدة شهر واحد من تاريخ اليوم"}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setSelectedUser(null)}
              >
                إلغاء
              </Button>
              <Button
                variant={selectedUser?.isActive ? "destructive" : "default"}
                onClick={() => {
                  if (selectedUser?.isActive) {
                    toggleUserMutation.mutate({
                      id: selectedUser.id,
                      isActive: false,
                      subscriptionEndsAt: null
                    });
                  } else {
                    handleActivateUser(selectedUser);
                  }
                }}
              >
                {selectedUser?.isActive ? "إلغاء التفعيل" : "تفعيل"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* حوار تعديل بيانات المستخدم */}
        <Dialog open={editMode} onOpenChange={() => setEditMode(false)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>تعديل بيانات المستخدم</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">اسم المستخدم</label>
                <Input
                  value={editData.username}
                  onChange={(e) => setEditData({ ...editData, username: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">بريد Quotex</label>
                <Input
                  value={editData.quotexEmail}
                  onChange={(e) => setEditData({ ...editData, quotexEmail: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">رقم حساب Quotex</label>
                <Input
                  value={editData.quotexAccountId}
                  onChange={(e) => setEditData({ ...editData, quotexAccountId: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">كلمة المرور الجديدة (اتركها فارغة إذا لم ترد تغييرها)</label>
                <Input
                  type="password"
                  value={editData.password}
                  onChange={(e) => setEditData({ ...editData, password: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditMode(false)}>
                إلغاء
              </Button>
              <Button
                onClick={() => {
                  const updateData = { ...editData };
                  if (!updateData.password) {
                    delete updateData.password;
                  }
                  updateUserMutation.mutate(updateData);
                }}
              >
                حفظ التغييرات
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
