import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { AlertTriangle, Power, PowerOff, CalendarClock, CheckCircle, XCircle } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { updateSettingsSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function UserPanel() {
  const { user, logoutMutation } = useAuth();
  const [botRunning, setBotRunning] = useState(false);
  const { toast } = useToast();

  const { data: settings = { investmentAmount: 1, dailyLossLimit: 1, isActive: false, subscriptionEndsAt: null } } = useQuery({
    queryKey: ["/api/user/settings"],
  });

  const form = useForm({
    resolver: zodResolver(updateSettingsSchema),
    defaultValues: {
      investmentAmount: settings?.investmentAmount || 1,
      dailyLossLimit: settings?.dailyLossLimit || 1,
    },
  });

  const settingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", "/api/user/settings", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/settings"] });
      toast({
        title: "تم حفظ الإعدادات",
        description: "تم حفظ إعدادات التداول الخاصة بك بنجاح.",
      });
    },
  });

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Bot Trading AI Quotex</h1>
          <Button variant="outline" onClick={() => logoutMutation.mutate()}>
            تسجيل الخروج
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>حالة الحساب</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                {settings.isActive ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
                <span>
                  حالة الحساب:{" "}
                  <span className={settings.isActive ? "text-green-500" : "text-red-500"}>
                    {settings.isActive ? "مفعل" : "غير مفعل"}
                  </span>
                </span>
              </div>
              {settings.subscriptionEndsAt && (
                <div className="flex items-center gap-2">
                  <CalendarClock className="h-5 w-5 text-blue-500" />
                  <span>
                    تاريخ انتهاء الاشتراك:{" "}
                    {format(new Date(settings.subscriptionEndsAt), "d MMMM yyyy", { locale: ar })}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>إعدادات التداول</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => settingsMutation.mutate(data))} className="space-y-4">
                <FormField
                  control={form.control}
                  name="investmentAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>مبلغ الاستثمار ($1 - $3000)</FormLabel>
                      <FormControl>
                        <Input type="number" min={1} max={3000} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="dailyLossLimit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>حد الخسارة اليومي ($1 - $500)</FormLabel>
                      <FormControl>
                        <Input type="number" min={1} max={500} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={settingsMutation.isPending}>
                  حفظ الإعدادات
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>التحكم في البوت</CardTitle>
          </CardHeader>
          <CardContent>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button disabled={!settings?.investmentAmount || !settings?.dailyLossLimit}>
                  {botRunning ? (
                    <>
                      <PowerOff className="mr-2 h-4 w-4" /> إيقاف البوت
                    </>
                  ) : (
                    <>
                      <Power className="mr-2 h-4 w-4" /> تشغيل البوت
                    </>
                  )}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>تأكيد تشغيل البوت</AlertDialogTitle>
                  <AlertDialogDescription>
                    تأكد من أن رصيد حساب Quotex الخاص بك أكثر من 20$ لتجنب خسارة رصيدك.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>إلغاء</AlertDialogCancel>
                  {settings.isActive ? (
                    <AlertDialogAction onClick={() => setBotRunning(!botRunning)}>تشغيل</AlertDialogAction>
                  ) : (
                    <AlertDialogAction asChild>
                      <a href="https://t.me/Drangeloo" target="_blank" rel="noopener noreferrer">
                        تواصل مع المسؤول للتفعيل
                      </a>
                    </AlertDialogAction>
                  )}
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            {botRunning && settings.isActive && (
              <p className="mt-4 text-sm text-green-500">
                البوت يعمل. يتم استخدام الإعدادات المكونة للتداول...
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}