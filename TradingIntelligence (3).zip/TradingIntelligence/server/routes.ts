import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { updateSettingsSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // User routes
  app.get("/api/user/settings", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const user = await storage.getUser(req.user.id);
    if (!user) return res.sendStatus(404);

    res.json({
      investmentAmount: user.investmentAmount,
      dailyLossLimit: user.dailyLossLimit,
      isActive: user.isActive,
      subscriptionEndsAt: user.subscriptionEndsAt
    });
  });

  app.patch("/api/user/settings", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const settings = updateSettingsSchema.parse(req.body);
      const updated = await storage.updateUserSettings(req.user.id, settings);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json(err.errors);
      } else {
        res.sendStatus(500);
      }
    }
  });

  // Admin routes
  app.get("/api/admin/users", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.sendStatus(403);
    }

    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.patch("/api/admin/users/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.sendStatus(403);
    }

    const userId = parseInt(req.params.id);
    const { isActive, subscriptionEndsAt, username, quotexEmail, quotexAccountId, password } = req.body;

    try {
      let updated;
      if (isActive !== undefined) {
        updated = await storage.updateUserStatus(userId, isActive, subscriptionEndsAt ? new Date(subscriptionEndsAt) : null);
      } else {
        updated = await storage.updateUser(userId, {
          username,
          quotexEmail,
          quotexAccountId,
          password: password ? await hashPassword(password) : undefined
        });
      }
      
      if (!updated) return res.sendStatus(404);
      res.json(updated);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  app.delete("/api/admin/users/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user.isAdmin) {
      return res.sendStatus(403);
    }

    const userId = parseInt(req.params.id);
    try {
      await storage.deleteUser(userId);
      res.sendStatus(200);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}