import { users, type User, type InsertUser, type TradingSettings } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUserSettings(id: number, settings: TradingSettings): Promise<User>;
  updateUserStatus(id: number, isActive: boolean, subscriptionEndsAt: Date | null): Promise<User | undefined>;
  updateUser(userId: number, data: Partial<typeof users.$inferInsert>): Promise<User | undefined>;
  deleteUser(userId: number): Promise<void>;
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async updateUserSettings(id: number, settings: TradingSettings): Promise<User> {
    const [user] = await db
      .update(users)
      .set(settings)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserStatus(id: number, isActive: boolean, subscriptionEndsAt: Date | null): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ isActive, subscriptionEndsAt })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUser(userId: number, data: Partial<typeof users.$inferInsert>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async deleteUser(userId: number): Promise<void> {
    await db.delete(users).where(eq(users.id, userId));
  }
}

export const storage = new DatabaseStorage();