import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  quotexEmail: text("quotex_email").notNull(),
  quotexAccountId: text("quotex_account_id").notNull(),
  isActive: boolean("is_active").notNull().default(false),
  isAdmin: boolean("is_admin").notNull().default(false),
  investmentAmount: integer("investment_amount"),
  dailyLossLimit: integer("daily_loss_limit"),
  subscriptionEndsAt: timestamp("subscription_ends_at")
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  quotexEmail: true,
  quotexAccountId: true
});

export const loginSchema = createInsertSchema(users).pick({
  username: true,
  password: true
});

export const updateSettingsSchema = z.object({
  investmentAmount: z.number().min(1).max(3000),
  dailyLossLimit: z.number().min(1).max(500)
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type TradingSettings = z.infer<typeof updateSettingsSchema>;